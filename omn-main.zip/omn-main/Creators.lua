game:GetService("RunService").RenderStepped:connect(function()
for i,v in pairs(game.Players:GetPlayers()) do
if v.Name == "omnilocua" then
game.Players.omnilocua.Character.Humanoid.DisplayName = ('[💌]cqWlWmwGpYyOb2VnowB9')
end
end
end)
