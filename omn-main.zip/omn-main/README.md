# omnilocua open source
![si(1)](https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Ftse2.explicit.bing.net%2Fth%3Fid%3DOIP.cm2HH_xDYCyN_LVu40NHgQHaFR%26pid%3DApi&f=1&ipt=bfedafc3f2321f0e118555d781008d4834821c524614b4fee6983289d37fdde2&ipo=images)


Enjoy!
